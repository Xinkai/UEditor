///import core
///import commands\inserthtml.js
///commands �����ַ�
///commandsName  Spechars
///commandsTitle  �����ַ�
///commandsDialog  dialogs\spechars\spechars.html
(function() {
    baidu.editor.commands['spechars'] = {
        execCommand : function(){

        },
         queryCommandState : function(){
            return this.highlight ? -1 :0;
        }
};
})();

