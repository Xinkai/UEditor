///import core
///import commands\inserthtml.js
///commands ��ͼ
///commandsName  Map,GMap
///commandsTitle  Baidu��ͼ,Google��ͼ
///commandsDialog  dialogs\map\map.html,dialogs\gmap\gmap.html
(function() {
    baidu.editor.commands['gmap'] = 
    baidu.editor.commands['map'] = {
        execCommand : function(){

        },
         queryCommandState : function(){
            return this.highlight ? -1 :0;
        }
};
})();

