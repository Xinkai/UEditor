///import core
///import commands\image.js
///commands �������
///commandsName  Emotion
///commandsTitle  ����
///commandsDialog  dialogs\emotion\emotion.html
(function() {
    baidu.editor.commands['emotion'] = {
        execCommand : function(){

        },
         queryCommandState : function(){
            return this.highlight ? -1 :0;
        }
};
})();

